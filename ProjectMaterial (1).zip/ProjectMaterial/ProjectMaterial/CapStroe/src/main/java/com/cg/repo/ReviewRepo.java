package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Review;

public interface ReviewRepo extends CrudRepository<Review, Integer> {

	
}
