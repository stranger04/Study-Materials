// tslint:disable-next-line:class-name
export class feedbackModal {
  // tslint:disable-next-line:ban-types
  public customerFirstName: string;
  public productComment: string;
  public productRating: string;
}
