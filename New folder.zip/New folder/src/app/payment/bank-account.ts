export class BankAccount {
    accountNumber: string;
    customerName: string;
    userName: string;
    userPassword: string;
    balance: number;
}