import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bag-page',
  templateUrl: './bag-page.component.html',
  styleUrls: ['./bag-page.component.scss']
})
export class BagPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
