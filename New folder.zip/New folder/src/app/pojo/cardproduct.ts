

import { Customer } from "./customer";
import { Product } from "./product";


export class CartProduct{
    serialNo:number;
    customer:Customer;
    product:Product;
    quantity:number;
    } 