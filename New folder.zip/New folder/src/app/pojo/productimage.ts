import { Product } from "./product";

export class ProductImage {

    imageId:number
    product:Product;
    imageUrl:string;
    imageStatus:string; 
}