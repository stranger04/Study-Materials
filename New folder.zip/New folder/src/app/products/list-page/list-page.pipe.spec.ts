import { ListPagePipe } from './list-page.pipe';

describe('ListPagePipe', () => {
  it('create an instance', () => {
    const pipe = new ListPagePipe();
    expect(pipe).toBeTruthy();
  });
});
