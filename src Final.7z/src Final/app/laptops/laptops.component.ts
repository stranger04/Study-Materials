import { Component, OnInit } from '@angular/core';
import { Products } from '../productview/products';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-laptops',
  templateUrl: './laptops.component.html',
  styleUrls: ['./laptops.component.css']
})
export class LaptopsComponent implements OnInit {
  products:Products[];
  start:boolean=false;
  constructor(private service:ProductsService,private router:Router) { }

  ngOnInit() {
    this.service.getProducts().subscribe(data => this.products=data);
  }
  verify(product:Products)
  {
   this.service.store(product);
   this.router.navigate(['/productsview'])
  }
}

