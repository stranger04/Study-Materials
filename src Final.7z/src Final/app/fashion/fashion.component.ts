import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl,Validators } from '@angular/forms';
import { Products } from 'src/app/productview/products';
import { ProductsService } from '../products.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-fashion',
  templateUrl: './fashion.component.html',
  styleUrls: ['./fashion.component.css']
})
export class FashionComponent implements OnInit {
 
  products:Products[];
  start:boolean=false;
 
  constructor(private service:ProductsService,private router:Router) { }
  ngOnInit() {
    this.service.getProducts().subscribe(data => this.products=data);
  
  }
  verify(product:Products)
  {
   this.service.store(product);
   this.router.navigate(['/productsview'])
  }
  }
  

