import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Products } from './productview/products';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  url : string = "http://localhost:8077/getproducts";
  product:Products
  constructor(private http: HttpClient) { }
  getProducts() : Observable<Products []>
  {
/*    let obj : Observable<IBook [] > = this.http.get(this.url);
    this.http.get(this.url);  */
return this.http.get<Products []>(this.url);
  }

store(product:Products):Products{
  this.product=product;
  return product;
}
recieve(){
  
  return this.product;
}

}


