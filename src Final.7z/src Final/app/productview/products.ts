export interface Products
{
    product_id:number;
    product_name:string;
    category_name:string;
      product_price:number;
      product_description:string;
      product_brand:string;
      product_discount:number;
      product_rating:number; 
      merchant_id : number;
      image:string;
}