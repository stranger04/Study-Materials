import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../products.service';
import { Products } from './products';

@Component({
  selector: 'app-productview',
  templateUrl: './productview.component.html',
  styleUrls: ['./productview.component.css']
})
export class ProductviewComponent implements OnInit {
  products : Products [] ;
  isUpdate : boolean = false;
  getProduct:Products;
  product_id:number;
  product_name:string;
  category_name:string;
    product_price:number;
    product_description:string;
    product_brand:string;
    product_discount:number;
    product_rating:number; 
    merchant_id : number;
    image:string;
  constructor(private service : ProductsService) { }

  ngOnInit() {
    this.service.getProducts().subscribe(data => this.products=data);
    this.getProduct=this.service.recieve();
  }

}
