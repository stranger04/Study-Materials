import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductsService } from '../products.service';
import { Products } from '../productview/products';


@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
products:Products[];
start:boolean=false;
  constructor(private service:ProductsService,private router:Router) { }

  ngOnInit() 
  {
    this.service.getProducts().subscribe(data => this.products=data);
  }


  verify(product:Products)
  {
   this.service.store(product);
   this.router.navigate(['/productsview'])
  }
  }
  
