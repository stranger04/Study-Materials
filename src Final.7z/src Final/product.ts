export class IProduct
{
    productId:number;
    productName:string;
    productCategory:string;   
    productPrice:number;
    productDescription:string;
    brand:string;
    discount:number;
    productrating:number;
   
} 