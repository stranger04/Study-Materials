import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { Route,RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ElectronicsComponent } from './electronics/electronics.component';
import { FashionComponent } from './fashion/fashion.component';
import { LaptopsComponent } from './laptops/laptops.component';



const routes : Route [] = [
  {
path : 'laptops',
component : LaptopsComponent
  },
  {
    path: 'fashion',
    component:FashionComponent
    
  },
  {
    path : 'electronics' ,
    component : ElectronicsComponent
  }];

@NgModule({
  declarations: [
    AppComponent,
    ElectronicsComponent,
    FashionComponent,
    LaptopsComponent

  ],
  imports: [
    BrowserModule,
FormsModule,
RouterModule.forRoot(routes),
HttpClientModule,
ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
