import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AddcartComponent } from './addcart/addcart.component';
import { Route, RouterModule } from '@angular/router';
const routes:Route[]=[{
  path:'addcart',
  component:AddcartComponent
  }];
@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
