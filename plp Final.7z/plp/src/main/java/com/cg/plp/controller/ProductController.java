package com.cg.plp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.plp.entity.Products;
import com.cg.plp.service.ProductService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/getproducts", method=RequestMethod.GET,headers="Accept=application/json")
	public List<Products> findAll(){
	return	productService.findAll();
	}

	@RequestMapping(value="/add/{id}/{name}/{quantity}/{price}/{description}/{rating}/{category}/{brand}/{discount}/{merchantid}/{image}", method=RequestMethod.POST,headers="Accept=application/json")
	public Products addTrainee(@PathVariable int id,@PathVariable String name,@PathVariable int quantity,
			@PathVariable double price,@PathVariable String description,@PathVariable double rating
			,@PathVariable String category,@PathVariable String brand,@PathVariable int discount,@PathVariable int merchantid,@PathVariable String image) {

		
		Products product=new Products(id,name,quantity,price,description,rating,category,brand,discount,merchantid,image);
	productService.create(product);
	return product;
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.GET,headers="Accept=application/json")
	public void delete(){
		productService.delete();
	}

	
	
	}
