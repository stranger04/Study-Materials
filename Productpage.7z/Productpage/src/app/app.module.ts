import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Route,RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ElectronicsComponent } from './electronics/electronics.component';
import { FashionComponent } from './fashion/fashion.component';
import { OthersComponent } from './others/others.component';

const routes : Route [] = [
  {
path : 'electronics',
component : ElectronicsComponent,
  },
  {
path : 'fashion',
component : FashionComponent
  },
  {
  path : 'others',
  component : OthersComponent
    }];

@NgModule({
  declarations: [
    AppComponent,
    ElectronicsComponent,
    FashionComponent,
    OthersComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
