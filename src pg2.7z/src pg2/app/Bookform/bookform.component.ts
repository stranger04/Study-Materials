import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { IBook } from '../book/book';
import { FormGroup, FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit {
  books: IBook[];
  userForm: FormGroup;

  constructor(private service:BookService) { }
  ngOnInit() {
  this.userForm=new FormGroup({
    id:new FormControl(),
    title:new FormControl('',[Validators.required,Validators.minLength(6)]),
    year:new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{4}$")]),
    author:new FormControl()
  });
  this.service.getBooks().subscribe(data=>this.books=data);

}
  onSubmit(obj:any)
  {
    // this.books.map(p=>p.title).forEach(p=>console.log(p));
    let arr=this.books.filter(p=>p.id==obj.id);
    if(arr.length>0)
    {
    alert("Id alreday exists");
    }
    else{
        this.books.push({id:obj.id,title:obj.title,year:obj.year,author:obj.author});
    /* console.log(obj.year); */
    /* console.log(obj.year); */
    }
  }

}
