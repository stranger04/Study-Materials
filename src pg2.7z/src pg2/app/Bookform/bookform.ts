export interface IBook{
    id:number,
    title:string,
    year:number,
    author:string
}