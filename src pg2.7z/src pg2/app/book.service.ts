import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { observable, Observable } from 'rxjs';
import {IBook} from './book/book';
@Injectable({
  providedIn: 'root'
})
export class BookService {
url : string = "assets/booklist.json";

  constructor(private http: HttpClient) {}

  getBooks() : Observable<IBook []>
  {
/*    let obj : Observable<IBook [] > = this.http.get(this.url);
    this.http.get(this.url);  */
return this.http.get<IBook []>(this.url);
  }
}
