import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { Route,RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BookComponent } from './Book/book.component';
import { UserComponent } from './User/user.component';
import { BookformComponent } from './Bookform/bookform.component';


const routes : Route [] = [
  {
path : 'bookform',
component : BookformComponent
  },
  {
    path: 'user',
    component:UserComponent
    
  },
  {
    path : 'book' ,
    component : BookComponent
  }];

@NgModule({
  declarations: [
    AppComponent,
   UserComponent,
    BookformComponent,
   BookComponent
  ],
  imports: [
    BrowserModule,
FormsModule,
RouterModule.forRoot(routes),
HttpClientModule,
ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
